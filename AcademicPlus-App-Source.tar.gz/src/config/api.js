// API Configuration for AcademicPlus
export const API_CONFIG = {
  // Google Gemini Configuration
  GEMINI_API_KEY: "AIzaSyCEjlD-PmSQoj09oLDo7fyeYAONASI-vSg",
  GEMINI_API_URL: "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent",
  
  // Request headers
  DEFAULT_HEADERS: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  },
  
  // AI Model Settings
  AI_SETTINGS: {
    maxTokens: 1000,
    temperature: 0.7,
    systemPrompt: "أنت مساعد تعليمي ذكي متخصص في مساعدة الطلاب الأكاديميين. تجيب باللغة العربية بشكل واضح ومفيد. تقدم شروحات مفصلة وأمثلة عملية عند الحاجة."
  }
};

// cURL command example for Gemini:
/*
curl "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=AIzaSyCEjlD-PmSQoj09oLDo7fyeYAONASI-vSg" \
  -H "Content-Type: application/json" \
  -d '{
    "contents": [{
      "parts": [{
        "text": "اشرح لي مفهوم الذكاء الاصطناعي"
      }]
    }],
    "generationConfig": {
      "temperature": 0.7,
      "maxOutputTokens": 1000
    }
  }'
*/

