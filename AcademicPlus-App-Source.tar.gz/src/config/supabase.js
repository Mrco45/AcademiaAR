// Supabase Configuration for AcademicPlus
import { createClient } from '@supabase/supabase-js'

// Supabase configuration
const supabaseUrl = 'https://fppkddgmulrfarxakczj.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZwcGtkZGdtdWxyZmFyeGFrY3pqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk1NjI1ODYsImV4cCI6MjA2NTEzODU4Nn0.O19MZyJtaIAhXSE-Fan_Fx-mO99bzgAOFB43Py0Kujc'

// إنشاء عميل Supabase
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export default supabase

