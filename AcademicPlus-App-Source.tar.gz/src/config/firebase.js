// Firebase Configuration for AcademicPlus
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyA6z8Ca0kQvpps2dk3DaQ6ZtgXLPnAZxsQ",
  authDomain: "eduplus-1ar.firebaseapp.com",
  projectId: "eduplus-1ar",
  storageBucket: "eduplus-1ar.firebasestorage.app",
  messagingSenderId: "253059702739",
  appId: "1:253059702739:web:3ac4ef12d99ee554a2d926",
  measurementId: "G-BS4SDXQJHP"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

// Only initialize analytics in browser environment
export let analytics = null;
if (typeof window !== 'undefined') {
  import("firebase/analytics").then(({ getAnalytics }) => {
    analytics = getAnalytics(app);
  });
}

export default app;

