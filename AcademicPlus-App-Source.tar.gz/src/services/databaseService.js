// Database Service for AcademicPlus using Supabase
import { supabase } from "../config/supabase";

export class DatabaseService {
  // حفظ محادثة جديدة
  static async saveConversation(userId, title = 'محادثة جديدة') {
    try {
      console.log('حفظ محادثة جديدة:', { userId, title });
      
      const { data, error } = await supabase
        .from('conversations')
        .insert([
          {
            user_id: userId,
            title: title,
            created_at: new Date().toISOString()
          }
        ])
        .select()
        .single();

      if (error) {
        console.error('خطأ في حفظ المحادثة:', error);
        throw error;
      }
      
      console.log('تم حفظ المحادثة بنجاح:', data);
      return { success: true, conversation: data };
    } catch (error) {
      console.error('Error saving conversation:', error);
      return { success: false, error: error.message };
    }
  }

  // حفظ رسالة في المحادثة
  static async saveMessage(conversationId, content, role) {
    try {
      console.log('حفظ رسالة جديدة:', { 
        conversationId, 
        content: content.substring(0, 50) + '...', 
        role,
        contentLength: content.length 
      });
      
      // التحقق من وجود المحادثة أولاً
      const { data: conversationCheck, error: checkError } = await supabase
        .from('conversations')
        .select('id')
        .eq('id', conversationId)
        .single();
        
      if (checkError) {
        console.error('المحادثة غير موجودة:', checkError);
        throw new Error('المحادثة غير موجودة: ' + checkError.message);
      }
      
      console.log('المحادثة موجودة:', conversationCheck);
      
      const { data, error } = await supabase
        .from('messages')
        .insert([
          {
            conversation_id: conversationId,
            content: content,
            role: role,
            created_at: new Date().toISOString()
          }
        ])
        .select()
        .single();

      if (error) {
        console.error('خطأ في حفظ الرسالة:', error);
        console.error('تفاصيل الخطأ:', {
          code: error.code,
          message: error.message,
          details: error.details,
          hint: error.hint
        });
        throw error;
      }
      
      console.log('تم حفظ الرسالة بنجاح:', data);
      return { success: true, message: data };
    } catch (error) {
      console.error('Error saving message:', error);
      return { success: false, error: error.message };
    }
  }

  // حفظ محادثة كاملة مع الرسائل
  static async saveFullConversation(userId, title, messages) {
    try {
      console.log('حفظ محادثة كاملة:', { userId, title, messagesCount: messages.length });
      
      // إنشاء محادثة جديدة
      const conversationResult = await this.saveConversation(userId, title);
      if (!conversationResult.success) {
        throw new Error(conversationResult.error);
      }

      const conversationId = conversationResult.conversation.id;
      console.log('تم إنشاء المحادثة بـ ID:', conversationId);

      // حفظ جميع الرسائل
      for (const message of messages) {
        const messageResult = await this.saveMessage(
          conversationId,
          message.content,
          message.role
        );
        if (!messageResult.success) {
          console.error('فشل في حفظ رسالة:', messageResult.error);
        }
      }

      console.log('تم حفظ المحادثة الكاملة بنجاح');
      return { success: true, conversationId };
    } catch (error) {
      console.error('Error saving full conversation:', error);
      return { success: false, error: error.message };
    }
  }

  // جلب رسائل محادثة معينة
  static async getConversationMessages(conversationId) {
    try {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: true });

      if (error) throw error;
      return { success: true, messages: data };
    } catch (error) {
      console.error('Error fetching conversation messages:', error);
      return { success: false, error: error.message };
    }
  }

  // جلب جميع المحادثات
  static async getAllConversations() {
    try {
      const { data, error } = await supabase
        .from('conversations')
        .select(`
          *,
          users(name, email, role),
          messages(content, role, created_at)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, conversations: data };
    } catch (error) {
      console.error('Error fetching conversations:', error);
      return { success: false, error: error.message };
    }
  }

  // جلب محادثات مستخدم معين
  static async getUserConversations(userId) {
    try {
      const { data, error } = await supabase
        .from('conversations')
        .select(`
          *,
          messages(content, role, created_at)
        `)
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, conversations: data };
    } catch (error) {
      console.error('Error fetching user conversations:', error);
      return { success: false, error: error.message };
    }
  }

  // جلب المحادثات المبلغ عنها (للمعلمين)
  static async getFlaggedConversations() {
    try {
      // هنا يمكن إضافة منطق للمحادثات المبلغ عنها
      // حالياً سنجلب آخر المحادثات
      const { data, error } = await supabase
        .from('conversations')
        .select(`
          *,
          users(name, email, role),
          messages(content, role, created_at)
        `)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      return { success: true, conversations: data };
    } catch (error) {
      console.error('Error fetching flagged conversations:', error);
      return { success: false, error: error.message };
    }
  }

  // حفظ سؤال وجواب من المعلم
  static async saveQASubmission(teacherId, question, answer, subject = '', difficulty = 'medium') {
    try {
      const { data, error } = await supabase
        .from('qa_submissions')
        .insert([
          {
            teacher_id: teacherId,
            question: question,
            answer: answer,
            subject: subject,
            difficulty: difficulty,
            status: 'pending',
            submitted_at: new Date().toISOString()
          }
        ])
        .select()
        .single();

      if (error) throw error;
      return { success: true, submission: data };
    } catch (error) {
      console.error('Error saving QA submission:', error);
      return { success: false, error: error.message };
    }
  }

  // جلب الأسئلة والأجوبة المعلقة (للمشرفين)
  static async getPendingQASubmissions() {
    try {
      const { data, error } = await supabase
        .from('qa_submissions')
        .select(`
          *,
          users(name, email)
        `)
        .eq('status', 'pending')
        .order('submitted_at', { ascending: false });

      if (error) throw error;
      return { success: true, submissions: data };
    } catch (error) {
      console.error('Error fetching pending QA submissions:', error);
      return { success: false, error: error.message };
    }
  }

  // تحديث حالة سؤال وجواب
  static async updateQASubmissionStatus(submissionId, status, reviewerId) {
    try {
      const { data, error } = await supabase
        .from('qa_submissions')
        .update({
          status: status,
          reviewed_by: reviewerId,
          reviewed_at: new Date().toISOString()
        })
        .eq('id', submissionId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, submission: data };
    } catch (error) {
      console.error('Error updating QA submission status:', error);
      return { success: false, error: error.message };
    }
  }

  // جلب إحصائيات النظام
  static async getSystemStats() {
    try {
      // عدد المستخدمين
      const { count: usersCount } = await supabase
        .from('users')
        .select('*', { count: 'exact', head: true });

      // عدد المحادثات
      const { count: conversationsCount } = await supabase
        .from('conversations')
        .select('*', { count: 'exact', head: true });

      // عدد الرسائل
      const { count: messagesCount } = await supabase
        .from('messages')
        .select('*', { count: 'exact', head: true });

      // عدد الأسئلة المعلقة
      const { count: pendingQACount } = await supabase
        .from('qa_submissions')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');

      return {
        success: true,
        stats: {
          users: usersCount || 0,
          conversations: conversationsCount || 0,
          messages: messagesCount || 0,
          pendingQA: pendingQACount || 0
        }
      };
    } catch (error) {
      console.error('Error fetching system stats:', error);
      return { success: false, error: error.message };
    }
  }

  // جلب جميع المستخدمين (للمشرفين)
  static async getAllUsers() {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, users: data };
    } catch (error) {
      console.error('Error fetching all users:', error);
      return { success: false, error: error.message };
    }
  }

  // تحديث دور المستخدم
  static async updateUserRole(userId, newRole) {
    try {
      const { data, error } = await supabase
        .from('users')
        .update({ role: newRole })
        .eq('id', userId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, user: data };
    } catch (error) {
      console.error('Error updating user role:', error);
      return { success: false, error: error.message };
    }
  }
}

