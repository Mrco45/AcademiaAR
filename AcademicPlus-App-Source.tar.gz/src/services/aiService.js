// AI Service for AcademicPlus - Updated with Real Gemini API
import axios from 'axios';
import { API_CONFIG } from '../config/api';

export class AIService {
  // خدمة الدردشة الذكية مع Gemini
  static async chatWithAI(message, conversationHistory = []) {
    try {
      // تحضير السياق من المحادثة السابقة
      let contextMessage = API_CONFIG.AI_SETTINGS.systemPrompt;
      
      if (conversationHistory.length > 0) {
        const recentHistory = conversationHistory.slice(-5); // آخر 5 رسائل
        const historyText = recentHistory.map(msg => 
          `${msg.role === 'user' ? 'الطالب' : 'المساعد'}: ${msg.content}`
        ).join('\n');
        contextMessage += `\n\nالمحادثة السابقة:\n${historyText}`;
      }
      
      contextMessage += `\n\nالسؤال الحالي: ${message}`;
      
      const response = await axios.post(
        `${API_CONFIG.GEMINI_API_URL}?key=${API_CONFIG.GEMINI_API_KEY}`,
        {
          contents: [{
            parts: [{
              text: contextMessage
            }]
          }],
          generationConfig: {
            temperature: API_CONFIG.AI_SETTINGS.temperature,
            maxOutputTokens: API_CONFIG.AI_SETTINGS.maxTokens,
            topP: 0.8,
            topK: 40
          },
          safetySettings: [
            {
              category: "HARM_CATEGORY_HARASSMENT",
              threshold: "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
              category: "HARM_CATEGORY_HATE_SPEECH", 
              threshold: "BLOCK_MEDIUM_AND_ABOVE"
            }
          ]
        },
        {
          headers: API_CONFIG.DEFAULT_HEADERS
        }
      );
      
      if (response.data && response.data.candidates && response.data.candidates[0]) {
        const aiResponse = response.data.candidates[0].content.parts[0].text;
        
        return {
          success: true,
          response: aiResponse,
          usage: {
            promptTokens: response.data.usageMetadata?.promptTokenCount || 0,
            completionTokens: response.data.usageMetadata?.candidatesTokenCount || 0,
            totalTokens: response.data.usageMetadata?.totalTokenCount || 0
          }
        };
      } else {
        throw new Error('Invalid response format from Gemini API');
      }
      
    } catch (error) {
      console.error('Gemini API Error:', error);
      
      // في حالة فشل API، استخدم استجابة احتياطية
      return {
        success: false,
        error: 'حدث خطأ في الاتصال بالمساعد الذكي',
        fallbackResponse: await this.getFallbackResponse(message)
      };
    }
  }
  
  // استجابة احتياطية في حالة فشل API
  static async getFallbackResponse(message) {
    const fallbackResponses = {
      'رياضيات': 'أعتذر، لا يمكنني الاتصال بالخدمة حالياً. بخصوص الرياضيات، يمكنك مراجعة الكتاب المدرسي أو طلب المساعدة من معلمك.',
      'فيزياء': 'أعتذر، لا يمكنني الاتصال بالخدمة حالياً. بخصوص الفيزياء، أنصحك بمراجعة القوانين الأساسية والتمارين العملية.',
      'كيمياء': 'أعتذر، لا يمكنني الاتصال بالخدمة حالياً. بخصوص الكيمياء، راجع الجدول الدوري والتفاعلات الأساسية.',
      'default': 'أعتذر، لا يمكنني الاتصال بالخدمة حالياً. يرجى المحاولة مرة أخرى لاحقاً أو التواصل مع معلمك للحصول على المساعدة.'
    };
    
    // البحث عن كلمات مفتاحية في السؤال
    const lowerMessage = message.toLowerCase();
    for (const [subject, response] of Object.entries(fallbackResponses)) {
      if (lowerMessage.includes(subject)) {
        return response;
      }
    }
    
    return fallbackResponses.default;
  }
  
  // خدمة التلخيص الذكي مع Gemini
  static async summarizeText(text) {
    try {
      const response = await axios.post(
        `${API_CONFIG.GEMINI_API_URL}?key=${API_CONFIG.GEMINI_API_KEY}`,
        {
          contents: [{
            parts: [{
              text: `قم بتلخيص النص التالي باللغة العربية بشكل مختصر ومفيد، مع الحفاظ على النقاط الرئيسية:\n\n${text}`
            }]
          }],
          generationConfig: {
            temperature: 0.3,
            maxOutputTokens: 500
          }
        },
        {
          headers: API_CONFIG.DEFAULT_HEADERS
        }
      );
      
      if (response.data && response.data.candidates && response.data.candidates[0]) {
        const summary = response.data.candidates[0].content.parts[0].text;
        
        return {
          success: true,
          summary: summary,
          originalLength: text.length,
          summaryLength: summary.length,
          compressionRatio: Math.round((1 - summary.length / text.length) * 100),
          usage: response.data.usageMetadata
        };
      } else {
        throw new Error('Invalid response format from Gemini API');
      }
      
    } catch (error) {
      console.error('Gemini Summarization Error:', error);
      
      // تلخيص احتياطي بسيط
      const sentences = text.split('.').filter(s => s.trim().length > 0);
      const summary = sentences.slice(0, Math.ceil(sentences.length / 3)).join('. ') + '.';
      
      return {
        success: false,
        error: 'حدث خطأ في خدمة التلخيص الذكي',
        fallbackSummary: summary,
        originalLength: text.length,
        summaryLength: summary.length,
        compressionRatio: Math.round((1 - summary.length / text.length) * 100)
      };
    }
  }
  
  // تحليل المحتوى التعليمي مع Gemini
  static async analyzeContent(content, subject) {
    try {
      const response = await axios.post(
        `${API_CONFIG.GEMINI_API_URL}?key=${API_CONFIG.GEMINI_API_KEY}`,
        {
          contents: [{
            parts: [{
              text: `حلل المحتوى التعليمي التالي في مادة ${subject} وقدم تقييماً شاملاً يتضمن:
              1. مستوى الصعوبة (سهل/متوسط/صعب)
              2. الموضوعات الرئيسية (3-5 موضوعات)
              3. الوقت المقدر للقراءة
              4. توصيات للدراسة
              
              المحتوى:
              ${content}`
            }]
          }],
          generationConfig: {
            temperature: 0.4,
            maxOutputTokens: 600
          }
        },
        {
          headers: API_CONFIG.DEFAULT_HEADERS
        }
      );
      
      if (response.data && response.data.candidates && response.data.candidates[0]) {
        const analysisText = response.data.candidates[0].content.parts[0].text;
        
        return {
          success: true,
          analysis: {
            fullAnalysis: analysisText,
            estimatedReadingTime: Math.ceil(content.length / 200) + ' دقائق',
            wordCount: content.split(' ').length,
            characterCount: content.length
          },
          usage: response.data.usageMetadata
        };
      } else {
        throw new Error('Invalid response format from Gemini API');
      }
      
    } catch (error) {
      console.error('Gemini Analysis Error:', error);
      
      return {
        success: false,
        error: 'حدث خطأ في تحليل المحتوى',
        fallbackAnalysis: {
          difficulty: Math.random() > 0.5 ? 'متوسط' : 'سهل',
          keyTopics: ['الموضوع الأول', 'الموضوع الثاني', 'الموضوع الثالث'],
          estimatedReadingTime: Math.ceil(content.length / 200) + ' دقائق',
          recommendations: [
            'ينصح بمراجعة المفاهيم الأساسية أولاً',
            'يمكن تقسيم المحتوى إلى أجزاء صغيرة للفهم الأفضل',
            'ممارسة التمارين العملية مهمة لترسيخ المعلومات'
          ]
        }
      };
    }
  }
  
  // فحص حالة API
  static async checkAPIStatus() {
    try {
      const response = await axios.post(
        `${API_CONFIG.GEMINI_API_URL}?key=${API_CONFIG.GEMINI_API_KEY}`,
        {
          contents: [{
            parts: [{
              text: "مرحبا"
            }]
          }]
        },
        {
          headers: API_CONFIG.DEFAULT_HEADERS,
          timeout: 5000
        }
      );
      
      return {
        success: true,
        status: 'متصل',
        model: 'Gemini 2.0 Flash'
      };
    } catch (error) {
      return {
        success: false,
        status: 'غير متصل',
        error: error.message
      };
    }
  }
}

