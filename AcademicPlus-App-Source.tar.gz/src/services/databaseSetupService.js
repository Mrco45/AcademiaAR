// Database Setup Service for AcademicPlus
import { supabase } from "../config/supabase";

export class DatabaseSetupService {
  // إنشاء جميع الجداول المطلوبة
  static async initializeDatabase() {
    try {
      console.log('بدء إعداد قاعدة البيانات...');
      
      // إنشاء جدول المستخدمين
      await this.createUsersTable();
      
      // إنشاء جدول المحادثات
      await this.createConversationsTable();
      
      // إنشاء جدول الرسائل
      await this.createMessagesTable();
      
      // إنشاء جدول الأسئلة والأجوبة
      await this.createQATable();
      
      // إنشاء جدول الإشعارات
      await this.createNotificationsTable();
      
      console.log('تم إعداد قاعدة البيانات بنجاح!');
      return { success: true };
    } catch (error) {
      console.error('خطأ في إعداد قاعدة البيانات:', error);
      return { success: false, error: error.message };
    }
  }

  // إنشاء جدول المستخدمين
  static async createUsersTable() {
    const { error } = await supabase.rpc('create_users_table', {});
    if (error && !error.message.includes('already exists')) {
      throw error;
    }
  }

  // إنشاء جدول المحادثات
  static async createConversationsTable() {
    const { error } = await supabase.rpc('create_conversations_table', {});
    if (error && !error.message.includes('already exists')) {
      throw error;
    }
  }

  // إنشاء جدول الرسائل
  static async createMessagesTable() {
    const { error } = await supabase.rpc('create_messages_table', {});
    if (error && !error.message.includes('already exists')) {
      throw error;
    }
  }

  // إنشاء جدول الأسئلة والأجوبة
  static async createQATable() {
    const { error } = await supabase.rpc('create_qa_table', {});
    if (error && !error.message.includes('already exists')) {
      throw error;
    }
  }

  // إنشاء جدول الإشعارات
  static async createNotificationsTable() {
    const { error } = await supabase.rpc('create_notifications_table', {});
    if (error && !error.message.includes('already exists')) {
      throw error;
    }
  }

  // إنشاء الجداول مباشرة (طريقة بديلة)
  static async createTablesDirectly() {
    try {
      // جدول المستخدمين
      await supabase.from('users').select('id').limit(1);
    } catch (error) {
      if (error.message.includes('does not exist')) {
        // الجدول غير موجود، سنستخدم طريقة بديلة
        console.log('الجداول غير موجودة، سيتم إنشاؤها تلقائياً عند أول استخدام');
      }
    }
  }

  // التحقق من وجود الجداول
  static async checkTablesExist() {
    try {
      const tables = ['users', 'conversations', 'messages', 'qa_submissions', 'notifications'];
      const results = {};
      
      for (const table of tables) {
        try {
          await supabase.from(table).select('*').limit(1);
          results[table] = true;
        } catch (error) {
          results[table] = false;
        }
      }
      
      return results;
    } catch (error) {
      console.error('خطأ في فحص الجداول:', error);
      return {};
    }
  }
}

