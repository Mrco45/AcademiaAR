// Authentication Service for AcademicPlus using Supabase
import { supabase } from "../config/supabase";

export class AuthService {
  // تسجيل مستخدم جديد
  static async register(email, password, userData) {
    try {
      console.log('بدء التسجيل مع البيانات:', userData);
      
      // إنشاء المستخدم
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: email,
        password: password,
        options: {
          data: {
            name: userData.name,
            role: userData.role || "student"
          }
        }
      });

      if (authError) {
        throw authError;
      }

      console.log('تم إنشاء المستخدم:', authData.user);

      // إضافة بيانات المستخدم إلى جدول المستخدمين
      if (authData.user) {
        const userProfile = {
          id: authData.user.id,
          name: userData.name,
          email: userData.email,
          role: userData.role || "student",
          created_at: new Date().toISOString(),
          last_login: new Date().toISOString()
        };

        console.log('حفظ بيانات المستخدم:', userProfile);

        const { data: profileData, error: profileError } = await supabase
          .from('users')
          .insert([userProfile])
          .select()
          .single();

        if (profileError) {
          console.error('خطأ في إنشاء الملف الشخصي:', profileError);
          // محاولة إنشاء الجدول إذا لم يكن موجوداً
          if (profileError.message.includes('does not exist')) {
            await this.createUsersTable();
            // إعادة المحاولة
            const { error: retryError } = await supabase
              .from('users')
              .insert([userProfile]);
            if (retryError) {
              console.error('فشل في إعادة المحاولة:', retryError);
            }
          }
        } else {
          console.log('تم حفظ بيانات المستخدم بنجاح:', profileData);
        }
      }
      
      return { success: true, user: authData.user, role: userData.role };
    } catch (error) {
      console.error('خطأ في التسجيل:', error);
      return { success: false, error: this.getErrorMessage(error.message) };
    }
  }
  
  // تسجيل الدخول
  static async login(email, password) {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email,
        password: password
      });

      if (error) {
        throw error;
      }

      console.log('تم تسجيل الدخول:', data.user);

      // تحديث آخر تسجيل دخول
      if (data.user) {
        await supabase
          .from('users')
          .update({ last_login: new Date().toISOString() })
          .eq('id', data.user.id);
      }
      
      return { success: true, user: data.user };
    } catch (error) {
      console.error('خطأ في تسجيل الدخول:', error);
      return { success: false, error: this.getErrorMessage(error.message) };
    }
  }
  
  // تسجيل الخروج
  static async logout() {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        throw error;
      }
      return { success: true };
    } catch (error) {
      console.error('خطأ في تسجيل الخروج:', error);
      return { success: false, error: error.message };
    }
  }
  
  // إعادة تعيين كلمة المرور
  static async resetPassword(email) {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email);
      if (error) {
        throw error;
      }
      return { success: true };
    } catch (error) {
      console.error('خطأ في إعادة تعيين كلمة المرور:', error);
      return { success: false, error: this.getErrorMessage(error.message) };
    }
  }
  
  // الحصول على بيانات المستخدم
  static async getUserData(uid) {
    try {
      console.log('البحث عن بيانات المستخدم:', uid);
      
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', uid)
        .single();

      if (error) {
        console.error('خطأ في الحصول على بيانات المستخدم:', error);
        
        // إذا لم يوجد المستخدم، إنشاء بيانات افتراضية
        if (error.code === 'PGRST116') {
          console.log('المستخدم غير موجود، إنشاء بيانات افتراضية...');
          const defaultUser = {
            id: uid,
            name: 'مستخدم جديد',
            email: 'user@example.com',
            role: 'student',
            created_at: new Date().toISOString(),
            last_login: new Date().toISOString()
          };
          
          const { data: newUser, error: insertError } = await supabase
            .from('users')
            .insert([defaultUser])
            .select()
            .single();
            
          if (insertError) {
            console.error('فشل في إنشاء بيانات افتراضية:', insertError);
            return { success: false, error: insertError.message };
          }
          
          return { success: true, data: newUser };
        }
        
        throw error;
      }
      
      console.log('تم العثور على بيانات المستخدم:', data);
      return { success: true, data };
    } catch (error) {
      console.error('خطأ في الحصول على بيانات المستخدم:', error);
      return { success: false, error: error.message };
    }
  }
  
  // مراقبة حالة المصادقة
  static onAuthStateChange(callback) {
    return supabase.auth.onAuthStateChange((event, session) => {
      console.log('تغيير حالة المصادقة:', event, session?.user?.id);
      callback(session?.user || null);
    });
  }

  // الحصول على المستخدم الحالي
  static async getCurrentUser() {
    try {
      const { data: { user }, error } = await supabase.auth.getUser();
      if (error) {
        throw error;
      }
      return user;
    } catch (error) {
      console.error('خطأ في الحصول على المستخدم الحالي:', error);
      return null;
    }
  }

  // إنشاء جدول المستخدمين إذا لم يكن موجوداً
  static async createUsersTable() {
    try {
      const { error } = await supabase.rpc('create_users_table_if_not_exists');
      if (error) {
        console.error('خطأ في إنشاء جدول المستخدمين:', error);
      }
    } catch (error) {
      console.error('خطأ في إنشاء جدول المستخدمين:', error);
    }
  }

  // تحديث دور المستخدم
  static async updateUserRole(userId, newRole) {
    try {
      const { data, error } = await supabase
        .from('users')
        .update({ role: newRole })
        .eq('id', userId)
        .select()
        .single();

      if (error) {
        throw error;
      }
      
      return { success: true, user: data };
    } catch (error) {
      console.error('خطأ في تحديث دور المستخدم:', error);
      return { success: false, error: error.message };
    }
  }

  // ترجمة رسائل الخطأ
  static getErrorMessage(errorMessage) {
    const errorMessages = {
      'Invalid login credentials': 'بيانات تسجيل الدخول غير صحيحة',
      'User already registered': 'المستخدم مسجل بالفعل',
      'Password should be at least 6 characters': 'كلمة المرور يجب أن تكون 6 أحرف على الأقل',
      'Invalid email': 'البريد الإلكتروني غير صحيح',
      'Email not confirmed': 'لم يتم تأكيد البريد الإلكتروني',
      'Too many requests': 'تم تجاوز عدد المحاولات المسموح',
      'Network error': 'خطأ في الاتصال بالشبكة'
    };
    
    // البحث عن رسالة مطابقة
    for (const [key, value] of Object.entries(errorMessages)) {
      if (errorMessage.includes(key)) {
        return value;
      }
    }
    
    return errorMessage || 'حدث خطأ غير متوقع';
  }
}

