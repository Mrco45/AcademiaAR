import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthService } from './services/authService';
import { DatabaseSetupService } from './services/databaseSetupService';
import LoginPage from './components/auth/LoginPage';
import RegisterPage from './components/auth/RegisterPage';
import ForgotPasswordPage from './components/auth/ForgotPasswordPage';
import StudentDashboard from './components/dashboards/StudentDashboard';
import TeacherDashboard from './components/dashboards/TeacherDashboard';
import AdminDashboard from './components/dashboards/AdminDashboard';
import LoadingSpinner from './components/ui/LoadingSpinner';
import './App.css';

function App() {
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dbInitialized, setDbInitialized] = useState(false);

  useEffect(() => {
    // إعداد قاعدة البيانات عند بدء التطبيق
    const initializeApp = async () => {
      try {
        console.log('بدء إعداد التطبيق...');
        
        // فحص الجداول الموجودة
        const tablesStatus = await DatabaseSetupService.checkTablesExist();
        console.log('حالة الجداول:', tablesStatus);
        
        setDbInitialized(true);
      } catch (error) {
        console.error('خطأ في إعداد التطبيق:', error);
        setDbInitialized(true); // المتابعة حتى لو فشل الإعداد
      }
    };

    initializeApp();
  }, []);

  useEffect(() => {
    if (!dbInitialized) return;

    // مراقبة حالة المصادقة
    const { data: { subscription } } = AuthService.onAuthStateChange(async (authUser) => {
      console.log('تغيير حالة المصادقة:', authUser?.id);
      
      if (authUser) {
        // الحصول على بيانات المستخدم من Supabase
        const userData = await AuthService.getUserData(authUser.id);
        console.log('بيانات المستخدم المسترجعة:', userData);
        
        if (userData.success) {
          setUser(authUser);
          setUserRole(userData.data.role);
          console.log('تم تعيين دور المستخدم:', userData.data.role);
        } else {
          // إذا لم توجد بيانات المستخدم، إنشاؤها بدور افتراضي
          console.log('إنشاء بيانات مستخدم جديدة...');
          setUser(authUser);
          setUserRole('student'); // الدور الافتراضي
        }
      } else {
        console.log('لا يوجد مستخدم مسجل دخول');
        setUser(null);
        setUserRole(null);
      }
      setLoading(false);
    });

    return () => {
      subscription?.unsubscribe();
    };
  }, [dbInitialized]);

  // عرض شاشة التحميل
  if (loading || !dbInitialized) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <LoadingSpinner />
          <p className="mt-4 text-gray-600">
            {!dbInitialized ? 'جاري إعداد قاعدة البيانات...' : 'جاري التحميل...'}
          </p>
        </div>
      </div>
    );
  }

  // إذا لم يكن المستخدم مسجل دخول
  if (!user) {
    return (
      <Router>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </Router>
    );
  }

  // توجيه المستخدم حسب دوره
  const getDashboardComponent = () => {
    console.log('اختيار لوحة التحكم للدور:', userRole);
    
    switch (userRole) {
      case 'admin':
        console.log('عرض لوحة تحكم المشرف');
        return <AdminDashboard user={user} />;
      case 'teacher':
        console.log('عرض لوحة تحكم المعلم');
        return <TeacherDashboard user={user} />;
      case 'student':
      default:
        console.log('عرض لوحة تحكم الطالب');
        return <StudentDashboard user={user} />;
    }
  };

  return (
    <Router>
      <div className="min-h-screen">
        {/* عرض معلومات التصحيح */}
        <div className="bg-blue-100 p-2 text-xs text-center">
          المستخدم: {user?.email} | الدور: {userRole || 'غير محدد'}
        </div>
        
        <Routes>
          <Route path="/dashboard" element={getDashboardComponent()} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

