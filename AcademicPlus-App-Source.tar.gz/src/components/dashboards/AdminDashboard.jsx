// Admin Dashboard Component
import React, { useState, useEffect } from 'react';
import { AuthService } from '../../services/authService';
import { DatabaseService } from '../../services/databaseService';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { 
  Users, 
  FileCheck, 
  MessageCircle, 
  Calendar, 
  Bell, 
  LogOut, 
  BookOpen,
  User,
  CheckCircle,
  XCircle,
  Eye,
  Shield,
  BarChart3
} from 'lucide-react';

const AdminDashboard = ({ user: propUser }) => {
  const [user, setUser] = useState(propUser);
  const [activeTab, setActiveTab] = useState('qa-review');
  const [pendingQAs, setPendingQAs] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [userChats, setUserChats] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedChat, setSelectedChat] = useState(null);
  const [showChatDetails, setShowChatDetails] = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalStudents: 0,
    totalTeachers: 0,
    pendingQAs: 0,
    approvedQAs: 0
  });

  useEffect(() => {
    const getCurrentUser = async () => {
      if (!user) {
        const currentUser = await AuthService.getCurrentUser();
        if (currentUser) {
          console.log('المستخدم الحالي في AdminDashboard:', currentUser);
          setUser(currentUser);
          
          // جلب بيانات المستخدم من قاعدة البيانات
          const userData = await AuthService.getUserData(currentUser.id);
          if (userData.success) {
            console.log('بيانات المشرف من قاعدة البيانات:', userData.data);
            setUser(prev => ({ ...prev, ...userData.data }));
          }
        }
      }
    };
    getCurrentUser();
    loadAdminData();
  }, [user]);

  const loadAdminData = async () => {
    setLoading(true);
    
    try {
      // تحميل الأسئلة والأجوبة المعلقة
      const qasResult = await DatabaseService.getPendingQASubmissions();
      if (qasResult.success) {
        setPendingQAs(qasResult.submissions);
      }

      // تحميل جميع المستخدمين
      const usersResult = await DatabaseService.getAllUsers();
      if (usersResult.success) {
        setAllUsers(usersResult.users);
        
        // حساب الإحصائيات
        const students = usersResult.users.filter(u => u.role === 'student').length;
        const teachers = usersResult.users.filter(u => u.role === 'teacher').length;
        
        setStats({
          totalUsers: usersResult.users.length,
          totalStudents: students,
          totalTeachers: teachers,
          pendingQAs: qasResult.success ? qasResult.submissions.length : 0,
          approvedQAs: 0 // يمكن إضافة استعلام منفصل
        });
      }

      // تحميل المحادثات الحقيقية
      console.log('جاري تحميل المحادثات...');
      const conversationsResult = await DatabaseService.getAllConversations();
      console.log('نتيجة تحميل المحادثات:', conversationsResult);
      
      if (conversationsResult.success) {
        console.log('المحادثات المحملة:', conversationsResult.conversations);
        const formattedChats = conversationsResult.conversations.map(conv => {
          console.log('معالجة محادثة:', conv);
          return {
            id: conv.id,
            userName: conv.users?.name || 'مستخدم غير معروف',
            userRole: conv.users?.role || 'student',
            lastMessage: conv.messages && conv.messages.length > 0 
              ? conv.messages[conv.messages.length - 1]?.content?.substring(0, 50) + '...' 
              : 'لا توجد رسائل',
            messageCount: conv.messages?.length || 0,
            lastActivity: new Date(conv.created_at),
            userId: conv.user_id
          };
        });
        console.log('المحادثات المنسقة:', formattedChats);
        setUserChats(formattedChats);
      } else {
        console.error('فشل في تحميل المحادثات:', conversationsResult.error);
      }

      // تحميل إحصائيات النظام
      const statsResult = await DatabaseService.getSystemStats();
      if (statsResult.success) {
        setStats(prev => ({
          ...prev,
          ...statsResult.stats
        }));
      }
    } catch (error) {
      console.error('Error loading admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApproveQA = async (qaId) => {
    try {
      const result = await DatabaseService.updateQASubmissionStatus(qaId, 'approved', user.id);
      if (result.success) {
        alert('تم قبول السؤال والجواب بنجاح!');
        loadAdminData(); // إعادة تحميل البيانات
      } else {
        alert('حدث خطأ في الموافقة: ' + result.error);
      }
    } catch (error) {
      console.error('Error approving QA:', error);
      alert('حدث خطأ غير متوقع');
    }
  };

  const handleRejectQA = async (qaId) => {
    try {
      const result = await DatabaseService.updateQASubmissionStatus(qaId, 'rejected', user.id);
      if (result.success) {
        alert('تم رفض السؤال والجواب');
        loadAdminData(); // إعادة تحميل البيانات
      } else {
        alert('حدث خطأ في الرفض: ' + result.error);
      }
    } catch (error) {
      console.error('Error rejecting QA:', error);
      alert('حدث خطأ غير متوقع');
    }
  };

  const handleUpdateUserRole = async (userId, newRole) => {
    try {
      const result = await DatabaseService.updateUserRole(userId, newRole);
      if (result.success) {
        alert('تم تحديث دور المستخدم بنجاح!');
        loadAdminData(); // إعادة تحميل البيانات
      } else {
        alert('حدث خطأ في التحديث: ' + result.error);
      }
    } catch (error) {
      console.error('Error updating user role:', error);
      alert('حدث خطأ غير متوقع');
    }
  };

  const handleLogout = async () => {
    await AuthService.logout();
  };

  const handleViewChatDetails = async (chat) => {
    try {
      setSelectedChat(chat);
      setShowChatDetails(true);
      
      // جلب رسائل المحادثة
      const messagesResult = await DatabaseService.getConversationMessages(chat.id);
      if (messagesResult.success) {
        setChatMessages(messagesResult.messages);
      } else {
        console.error('فشل في جلب رسائل المحادثة:', messagesResult.error);
        setChatMessages([]);
      }
    } catch (error) {
      console.error('Error viewing chat details:', error);
      alert('حدث خطأ في عرض تفاصيل المحادثة');
    }
  };

  const handleCloseChatDetails = () => {
    setShowChatDetails(false);
    setSelectedChat(null);
    setChatMessages([]);
  };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <BookOpen className="h-8 w-8 text-purple-600 ml-3" />
              <h1 className="text-xl font-semibold text-gray-900">AcademicPlus - المشرف</h1>
            </div>
            
            <div className="flex items-center space-x-4 space-x-reverse">
              <div className="flex items-center">
                <Shield className="h-5 w-5 text-gray-400 ml-2" />
                <span className="text-sm text-gray-700">{user.displayName || user.email}</span>
                <Badge variant="destructive" className="mr-2">مشرف</Badge>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleLogout}
                className="flex items-center"
              >
                <LogOut className="h-4 w-4 ml-1" />
                تسجيل الخروج
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Stats Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-blue-600" />
                <div className="mr-4">
                  <p className="text-2xl font-bold text-gray-900">{stats.totalUsers}</p>
                  <p className="text-sm text-gray-600">إجمالي المستخدمين</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <User className="h-8 w-8 text-green-600" />
                <div className="mr-4">
                  <p className="text-2xl font-bold text-gray-900">{stats.totalStudents}</p>
                  <p className="text-sm text-gray-600">الطلاب</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <BookOpen className="h-8 w-8 text-purple-600" />
                <div className="mr-4">
                  <p className="text-2xl font-bold text-gray-900">{stats.totalTeachers}</p>
                  <p className="text-sm text-gray-600">المعلمون</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <FileCheck className="h-8 w-8 text-orange-600" />
                <div className="mr-4">
                  <p className="text-2xl font-bold text-gray-900">{stats.pendingQAs}</p>
                  <p className="text-sm text-gray-600">أسئلة معلقة</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <CheckCircle className="h-8 w-8 text-green-600" />
                <div className="mr-4">
                  <p className="text-2xl font-bold text-gray-900">{stats.approvedQAs}</p>
                  <p className="text-sm text-gray-600">أسئلة مقبولة</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="qa-review" className="flex items-center">
              <FileCheck className="h-4 w-4 ml-2" />
              مراجعة الأسئلة
              {pendingQAs.length > 0 && (
                <Badge variant="destructive" className="mr-1 text-xs">
                  {pendingQAs.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="user-management" className="flex items-center">
              <Users className="h-4 w-4 ml-2" />
              إدارة المستخدمين
            </TabsTrigger>
            <TabsTrigger value="chat-monitoring" className="flex items-center">
              <Eye className="h-4 w-4 ml-2" />
              مراقبة المحادثات
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center">
              <BarChart3 className="h-4 w-4 ml-2" />
              التحليلات
            </TabsTrigger>
          </TabsList>

          {/* Q&A Review Tab */}
          <TabsContent value="qa-review">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileCheck className="h-5 w-5 ml-2" />
                  مراجعة الأسئلة والأجوبة المرسلة
                </CardTitle>
                <CardDescription>
                  راجع واعتمد الأسئلة والأجوبة المرسلة من المعلمين
                </CardDescription>
              </CardHeader>
              <CardContent>
                {pendingQAs.length === 0 ? (
                  <div className="text-center py-12">
                    <CheckCircle className="h-16 w-16 mx-auto text-green-300 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد أسئلة معلقة</h3>
                    <p className="text-gray-500">
                      جميع الأسئلة المرسلة تمت مراجعتها
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pendingQAs.map((qa) => (
                      <div key={qa.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900 mb-2">السؤال:</h4>
                            <p className="text-sm text-gray-700 mb-3 bg-gray-50 p-3 rounded">
                              {qa.question}
                            </p>
                            
                            <h4 className="font-medium text-gray-900 mb-2">الإجابة:</h4>
                            <p className="text-sm text-gray-700 mb-3 bg-blue-50 p-3 rounded">
                              {qa.answer}
                            </p>
                            
                            <div className="flex items-center space-x-4 space-x-reverse text-xs text-gray-500">
                              <span>المادة: {qa.subject}</span>
                              <span>الصعوبة: {qa.difficulty}</span>
                              <span>
                                تاريخ الإرسال: {new Date(qa.submittedAt?.seconds * 1000).toLocaleDateString('ar-SA')}
                              </span>
                            </div>
                            
                            {qa.tags && qa.tags.length > 0 && (
                              <div className="mt-2">
                                <span className="text-xs text-gray-500 ml-2">الكلمات المفتاحية:</span>
                                {qa.tags.map((tag, index) => (
                                  <Badge key={index} variant="outline" className="text-xs mr-1">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex justify-end space-x-2 space-x-reverse">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleRejectQA(qa.id)}
                            className="flex items-center"
                          >
                            <XCircle className="h-4 w-4 ml-1" />
                            رفض
                          </Button>
                          <Button 
                            size="sm"
                            onClick={() => handleApproveQA(qa.id)}
                            className="flex items-center"
                          >
                            <CheckCircle className="h-4 w-4 ml-1" />
                            قبول
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* User Management Tab */}
          <TabsContent value="user-management">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="h-5 w-5 ml-2" />
                  إدارة المستخدمين
                </CardTitle>
                <CardDescription>
                  عرض وإدارة جميع مستخدمي النظام
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {allUsers.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4 space-x-reverse">
                        <User className="h-8 w-8 text-gray-400" />
                        <div>
                          <h4 className="font-medium text-gray-900">{user.name}</h4>
                          <p className="text-sm text-gray-600">{user.email}</p>
                          <p className="text-xs text-gray-500">
                            انضم في: {new Date(user.createdAt?.seconds * 1000).toLocaleDateString('ar-SA')}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <Badge 
                          variant={user.role === 'admin' ? 'destructive' : 
                                  user.role === 'teacher' ? 'default' : 'secondary'}
                        >
                          {user.role === 'admin' ? 'مشرف' : 
                           user.role === 'teacher' ? 'معلم' : 'طالب'}
                        </Badge>
                        
                        <Select 
                          value={user.role} 
                          onValueChange={(newRole) => handleChangeUserRole(user.id, newRole)}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="student">طالب</SelectItem>
                            <SelectItem value="teacher">معلم</SelectItem>
                            <SelectItem value="admin">مشرف</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Chat Monitoring Tab */}
          <TabsContent value="chat-monitoring">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Eye className="h-5 w-5 ml-2" />
                  مراقبة المحادثات
                </CardTitle>
                <CardDescription>
                  عرض نشاط المحادثات في النظام
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="text-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                    <p className="text-gray-500">جاري تحميل المحادثات...</p>
                  </div>
                ) : userChats.length === 0 ? (
                  <div className="text-center py-12">
                    <MessageCircle className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد محادثات</h3>
                    <p className="text-gray-500">
                      لم يبدأ أي طالب محادثة بعد
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {userChats.map((chat) => (
                      <div key={chat.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                        <div className="flex items-center space-x-4 space-x-reverse">
                          <MessageCircle className="h-8 w-8 text-blue-400" />
                          <div>
                            <div className="flex items-center space-x-2 space-x-reverse mb-1">
                              <h4 className="font-medium text-gray-900">{chat.userName}</h4>
                              <Badge 
                                variant={chat.userRole === 'admin' ? 'destructive' : 
                                        chat.userRole === 'teacher' ? 'default' : 'secondary'}
                                className="text-xs"
                              >
                                {chat.userRole === 'admin' ? 'مشرف' : 
                                 chat.userRole === 'teacher' ? 'معلم' : 'طالب'}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600 mb-1">"{chat.lastMessage}"</p>
                            <p className="text-xs text-gray-500">
                              آخر نشاط: {chat.lastActivity.toLocaleString('ar-SA')}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <Badge variant="outline" className="text-xs">
                            {chat.messageCount} رسالة
                          </Badge>
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="text-xs"
                            onClick={() => handleViewChatDetails(chat)}
                          >
                            <Eye className="h-4 w-4 ml-1" />
                            عرض التفاصيل
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="h-5 w-5 ml-2" />
                  التحليلات والإحصائيات
                </CardTitle>
                <CardDescription>
                  إحصائيات استخدام النظام
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <BarChart3 className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">قريباً</h3>
                  <p className="text-gray-500">
                    ستتوفر التحليلات والإحصائيات المفصلة قريباً
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Chat Details Modal */}
      {showChatDetails && selectedChat && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" dir="rtl">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b">
              <div className="flex items-center space-x-3 space-x-reverse">
                <MessageCircle className="h-6 w-6 text-blue-600" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    محادثة {selectedChat.userName}
                  </h3>
                  <p className="text-sm text-gray-500">
                    {chatMessages.length} رسالة • آخر نشاط: {selectedChat.lastActivity.toLocaleString('ar-SA')}
                  </p>
                </div>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleCloseChatDetails}
              >
                إغلاق
              </Button>
            </div>

            {/* Messages Content */}
            <div className="p-6 overflow-y-auto max-h-[60vh]">
              {chatMessages.length === 0 ? (
                <div className="text-center py-12">
                  <MessageCircle className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد رسائل</h3>
                  <p className="text-gray-500">لم يتم العثور على رسائل في هذه المحادثة</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {chatMessages.map((message, index) => (
                    <div 
                      key={index} 
                      className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div 
                        className={`max-w-[70%] p-4 rounded-lg ${
                          message.role === 'user' 
                            ? 'bg-blue-600 text-white' 
                            : 'bg-gray-100 text-gray-900'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-medium">
                            {message.role === 'user' ? selectedChat.userName : 'المساعد الذكي'}
                          </span>
                          <span className="text-xs opacity-70">
                            {new Date(message.created_at).toLocaleString('ar-SA')}
                          </span>
                        </div>
                        <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;

