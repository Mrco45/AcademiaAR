// Teacher Dashboard Component
import React, { useState, useEffect } from 'react';
import { AuthService } from '../../services/authService';
import { DatabaseService } from '../../services/databaseService';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { 
  MessageCircle, 
  FileText, 
  Calendar, 
  Bell, 
  LogOut, 
  BookOpen,
  User,
  Plus,
  Eye,
  CheckCircle,
  AlertTriangle,
  Users
} from 'lucide-react';

const TeacherDashboard = ({ user: propUser }) => {
  const [user, setUser] = useState(propUser);
  const [activeTab, setActiveTab] = useState('qa-management');
  const [qaForm, setQaForm] = useState({
    question: '',
    answer: '',
    subject: '',
    difficulty: 'medium',
    tags: ''
  });
  const [submittedQAs, setSubmittedQAs] = useState([]);
  const [flaggedChats, setFlaggedChats] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const getCurrentUser = async () => {
      if (!user) {
        const currentUser = await AuthService.getCurrentUser();
        if (currentUser) {
          console.log('المستخدم الحالي في TeacherDashboard:', currentUser);
          setUser(currentUser);
          
          // جلب بيانات المستخدم من قاعدة البيانات
          const userData = await AuthService.getUserData(currentUser.id);
          if (userData.success) {
            console.log('بيانات المعلم من قاعدة البيانات:', userData.data);
            setUser(prev => ({ ...prev, ...userData.data }));
          }
        }
      }
    };
    getCurrentUser();
    loadTeacherData();
  }, [user]);

  const loadTeacherData = async () => {
    setLoading(true);
    try {
      // تحميل الأسئلة والأجوبة المرسلة
      const qasResult = await DatabaseService.getPendingQASubmissions();
      if (qasResult.success) {
        setSubmittedQAs(qasResult.submissions);
      }

      // تحميل المحادثات المبلغ عنها (جلب المحادثات الحقيقية)
      const conversationsResult = await DatabaseService.getFlaggedConversations();
      if (conversationsResult.success) {
        // تحويل المحادثات إلى تنسيق مناسب للعرض
        const formattedChats = conversationsResult.conversations.map(conv => ({
          id: conv.id,
          studentName: conv.users?.name || 'مستخدم غير معروف',
          studentEmail: conv.users?.email || '',
          message: conv.messages?.[0]?.content?.substring(0, 100) + '...' || 'لا توجد رسائل',
          flagReason: 'محادثة تحتاج مراجعة',
          timestamp: new Date(conv.created_at),
          status: 'pending',
          conversationId: conv.id,
          messagesCount: conv.messages?.length || 0
        }));
        setFlaggedChats(formattedChats);
      }
    } catch (error) {
      console.error('Error loading teacher data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleQASubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      console.log('إرسال سؤال وجواب من المعلم:', user.id);
      const result = await DatabaseService.saveQASubmission(
        user.id, 
        qaForm.question,
        qaForm.answer,
        qaForm.subject,
        qaForm.difficulty
      );

      if (result.success) {
        alert('تم إرسال السؤال والجواب بنجاح!');
        setQaForm({
          question: '',
          answer: '',
          subject: '',
          difficulty: 'medium',
          tags: ''
        });
        loadTeacherData(); // إعادة تحميل البيانات
      } else {
        alert('حدث خطأ في الإرسال: ' + result.error);
      }
    } catch (error) {
      console.error('Error submitting QA:', error);
      alert('حدث خطأ غير متوقع');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setQaForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleLogout = async () => {
    await AuthService.logout();
  };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <BookOpen className="h-8 w-8 text-green-600 ml-3" />
              <h1 className="text-xl font-semibold text-gray-900">AcademicPlus - المعلم</h1>
            </div>
            
            <div className="flex items-center space-x-4 space-x-reverse">
              <div className="flex items-center">
                <User className="h-5 w-5 text-gray-400 ml-2" />
                <span className="text-sm text-gray-700">{user.displayName || user.email}</span>
                <Badge variant="secondary" className="mr-2">معلم</Badge>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleLogout}
                className="flex items-center"
              >
                <LogOut className="h-4 w-4 ml-1" />
                تسجيل الخروج
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="qa-management" className="flex items-center">
              <Plus className="h-4 w-4 ml-2" />
              إدارة الأسئلة
            </TabsTrigger>
            <TabsTrigger value="chat-review" className="flex items-center">
              <Eye className="h-4 w-4 ml-2" />
              مراجعة المحادثات
              {flaggedChats.filter(chat => chat.status === 'pending').length > 0 && (
                <Badge variant="destructive" className="mr-1 text-xs">
                  {flaggedChats.filter(chat => chat.status === 'pending').length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="chat" className="flex items-center">
              <MessageCircle className="h-4 w-4 ml-2" />
              المساعد الذكي
            </TabsTrigger>
            <TabsTrigger value="calendar" className="flex items-center">
              <Calendar className="h-4 w-4 ml-2" />
              التقويم
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center">
              <Bell className="h-4 w-4 ml-2" />
              الإشعارات
            </TabsTrigger>
          </TabsList>

          {/* Q&A Management Tab */}
          <TabsContent value="qa-management">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Add New Q&A */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Plus className="h-5 w-5 ml-2" />
                    إضافة سؤال وجواب جديد
                  </CardTitle>
                  <CardDescription>
                    أضف أسئلة وأجوبة لتحسين المساعد الذكي
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleQASubmit} className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-2 block">
                        السؤال
                      </label>
                      <Textarea
                        name="question"
                        value={qaForm.question}
                        onChange={handleInputChange}
                        placeholder="اكتب السؤال هنا..."
                        required
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-2 block">
                        الإجابة
                      </label>
                      <Textarea
                        name="answer"
                        value={qaForm.answer}
                        onChange={handleInputChange}
                        placeholder="اكتب الإجابة هنا..."
                        className="min-h-24"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">
                          المادة
                        </label>
                        <Input
                          name="subject"
                          value={qaForm.subject}
                          onChange={handleInputChange}
                          placeholder="مثل: رياضيات، فيزياء..."
                          required
                        />
                      </div>

                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">
                          مستوى الصعوبة
                        </label>
                        <Select 
                          value={qaForm.difficulty} 
                          onValueChange={(value) => setQaForm(prev => ({...prev, difficulty: value}))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="easy">سهل</SelectItem>
                            <SelectItem value="medium">متوسط</SelectItem>
                            <SelectItem value="hard">صعب</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-2 block">
                        الكلمات المفتاحية (مفصولة بفواصل)
                      </label>
                      <Input
                        name="tags"
                        value={qaForm.tags}
                        onChange={handleInputChange}
                        placeholder="مثل: جبر، معادلات، حل..."
                      />
                    </div>

                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading ? 'جاري الإرسال...' : 'إرسال للمراجعة'}
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {/* Submitted Q&As */}
              <Card>
                <CardHeader>
                  <CardTitle>الأسئلة المرسلة</CardTitle>
                  <CardDescription>
                    حالة الأسئلة والأجوبة التي أرسلتها
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {submittedQAs.length === 0 ? (
                    <div className="text-center py-8">
                      <FileText className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                      <p className="text-gray-500">لم ترسل أي أسئلة بعد</p>
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {submittedQAs.map((qa) => (
                        <div key={qa.id} className="border rounded-lg p-3">
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-medium text-sm">{qa.question.substring(0, 50)}...</h4>
                            <Badge 
                              variant={qa.status === 'approved' ? 'default' : 'secondary'}
                              className="text-xs"
                            >
                              {qa.status === 'pending' ? 'قيد المراجعة' : 
                               qa.status === 'approved' ? 'مقبول' : 'مرفوض'}
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-600 mb-2">
                            المادة: {qa.subject} | الصعوبة: {qa.difficulty}
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(qa.submittedAt?.seconds * 1000).toLocaleDateString('ar-SA')}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Chat Review Tab */}
          <TabsContent value="chat-review">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Eye className="h-5 w-5 ml-2" />
                  مراجعة المحادثات المبلغ عنها
                </CardTitle>
                <CardDescription>
                  راجع المحادثات التي تم الإبلاغ عنها من قبل النظام
                </CardDescription>
              </CardHeader>
              <CardContent>
                {flaggedChats.length === 0 ? (
                  <div className="text-center py-12">
                    <CheckCircle className="h-16 w-16 mx-auto text-green-300 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد محادثات مبلغ عنها</h3>
                    <p className="text-gray-500">
                      جميع المحادثات تبدو طبيعية
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {flaggedChats.map((chat) => (
                      <div key={chat.id} className="border border-orange-200 rounded-lg p-4 bg-orange-50">
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex items-center">
                            <AlertTriangle className="h-5 w-5 text-orange-500 ml-2" />
                            <div>
                              <h4 className="font-medium text-gray-900">{chat.studentName}</h4>
                              <p className="text-sm text-orange-600">{chat.flagReason}</p>
                            </div>
                          </div>
                          <Badge variant="outline" className="text-orange-600 border-orange-300">
                            {chat.status === 'pending' ? 'قيد المراجعة' : 'تمت المراجعة'}
                          </Badge>
                        </div>
                        
                        <div className="bg-white rounded p-3 mb-3">
                          <p className="text-sm text-gray-700">"{chat.message}"</p>
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-gray-500">
                            {chat.timestamp.toLocaleString('ar-SA')}
                          </span>
                          {chat.status === 'pending' && (
                            <div className="space-x-2 space-x-reverse">
                              <Button size="sm" variant="outline">
                                تجاهل
                              </Button>
                              <Button size="sm" variant="destructive">
                                إبلاغ المشرف
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Other tabs would be similar to StudentDashboard */}
          <TabsContent value="chat">
            <Card>
              <CardHeader>
                <CardTitle>المساعد الذكي</CardTitle>
                <CardDescription>
                  نفس ميزات الطلاب متاحة للمعلمين أيضاً
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <MessageCircle className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500">
                    يمكنك استخدام نفس ميزات المساعد الذكي المتاحة للطلاب
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="calendar">
            <Card>
              <CardHeader>
                <CardTitle>التقويم</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Calendar className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500">ميزة التقويم قيد التطوير</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>الإشعارات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Bell className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500">لا توجد إشعارات جديدة</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default TeacherDashboard;

