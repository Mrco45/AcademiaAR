// Student Dashboard Component
import { useState, useEffect } from 'react';
import { AuthService } from '../../services/authService';
import { AIService } from '../../services/aiService';
import { DatabaseService } from '../../services/databaseService';
import { 
  BookOpen, 
  MessageCircle, 
  FileText, 
  Calendar, 
  Bell, 
  User, 
  LogOut, 
  Send,
  Loader2,
  Home
} from 'lucide-react';
import LoadingSpinner from '../ui/LoadingSpinner';

const StudentDashboard = () => {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('home');
  const [chatMessage, setChatMessage] = useState('');
  const [chatHistory, setChatHistory] = useState([]);
  const [chatLoading, setChatLoading] = useState(false);
  const [summarizeText, setSummarizeText] = useState('');
  const [summaryResult, setSummaryResult] = useState(null);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [currentConversationId, setCurrentConversationId] = useState(null);

  useEffect(() => {
    const getCurrentUser = async () => {
      const currentUser = await AuthService.getCurrentUser();
      if (currentUser) {
        console.log('المستخدم الحالي:', currentUser);
        setUser(currentUser);
        
        // جلب بيانات المستخدم من قاعدة البيانات
        const userData = await AuthService.getUserData(currentUser.id);
        if (userData.success) {
          console.log('بيانات المستخدم من قاعدة البيانات:', userData.data);
          setUser(prev => ({ ...prev, ...userData.data }));
        }
      }
    };
    getCurrentUser();
  }, []);

  const handleChatSubmit = async (e) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;

    setChatLoading(true);
    
    // إضافة رسالة المستخدم إلى التاريخ
    const newMessage = { role: 'user', content: chatMessage, timestamp: new Date() };
    const updatedHistory = [...chatHistory, newMessage];
    setChatHistory(updatedHistory);
    
    const currentMessage = chatMessage;
    setChatMessage('');

    try {
      // إنشاء محادثة جديدة إذا لم تكن موجودة
      let conversationId = currentConversationId;
      if (!conversationId) {
        console.log('إنشاء محادثة جديدة للمستخدم:', user.id);
        const conversationResult = await DatabaseService.saveConversation(
          user.id, 
          currentMessage.substring(0, 50) + '...'
        );
        
        if (conversationResult.success) {
          conversationId = conversationResult.conversation.id;
          setCurrentConversationId(conversationId);
          console.log('تم إنشاء محادثة جديدة:', conversationId);
        } else {
          console.error('فشل في إنشاء المحادثة:', conversationResult.error);
        }
      }

      // حفظ رسالة المستخدم
      if (conversationId) {
        const userMessageResult = await DatabaseService.saveMessage(conversationId, currentMessage, 'user');
        if (!userMessageResult.success) {
          console.error('فشل في حفظ رسالة المستخدم:', userMessageResult.error);
        }
      }

      // إرسال الرسالة إلى AI
      const response = await AIService.chatWithAI(currentMessage, chatHistory);
      
      if (response.success) {
        const aiMessage = { 
          role: 'assistant', 
          content: response.response, 
          timestamp: new Date() 
        };
        const finalHistory = [...updatedHistory, aiMessage];
        setChatHistory(finalHistory);

        // حفظ رد الـ AI
        if (conversationId) {
          const aiMessageResult = await DatabaseService.saveMessage(conversationId, response.response, 'assistant');
          if (!aiMessageResult.success) {
            console.error('فشل في حفظ رد الـ AI:', aiMessageResult.error);
          }
        }
      } else {
        // في حالة فشل API، استخدم الاستجابة الاحتياطية
        const fallbackMessage = { 
          role: 'assistant', 
          content: response.fallbackResponse || 'أعتذر، حدث خطأ في الخدمة. يرجى المحاولة مرة أخرى.', 
          timestamp: new Date() 
        };
        const finalHistory = [...updatedHistory, fallbackMessage];
        setChatHistory(finalHistory);

        // حفظ الرد الاحتياطي
        if (conversationId) {
          const fallbackMessageResult = await DatabaseService.saveMessage(conversationId, fallbackMessage.content, 'assistant');
          if (!fallbackMessageResult.success) {
            console.error('فشل في حفظ الرد الاحتياطي:', fallbackMessageResult.error);
          }
        }
      }
    } catch (error) {
      console.error('Chat error:', error);
      const errorMessage = { 
        role: 'assistant', 
        content: 'أعتذر، حدث خطأ في الاتصال. يرجى المحاولة مرة أخرى.', 
        timestamp: new Date() 
      };
      setChatHistory([...updatedHistory, errorMessage]);
    } finally {
      setChatLoading(false);
    }
  };

  const startNewConversation = () => {
    setChatHistory([]);
    setCurrentConversationId(null);
  };

  const handleSummarize = async () => {
    if (!summarizeText.trim()) return;

    setSummaryLoading(true);
    try {
      const result = await AIService.summarizeText(summarizeText);
      setSummaryResult(result);
    } catch (error) {
      console.error('Summarization error:', error);
      setSummaryResult({
        success: false,
        error: 'حدث خطأ في عملية التلخيص'
      });
    } finally {
      setSummaryLoading(false);
    }
  };

  const handleLogout = async () => {
    await AuthService.logout();
  };

  if (!user) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <BookOpen className="h-8 w-8 text-blue-600 ml-3" />
              <h1 className="text-xl font-semibold text-gray-900">AcademicPlus</h1>
            </div>
            
            <div className="flex items-center space-x-4 space-x-reverse">
              <div className="flex items-center">
                <User className="h-5 w-5 text-gray-400 ml-2" />
                <span className="text-sm text-gray-700">{user.displayName || user.email}</span>
                <span className="text-xs text-blue-600 mr-2">طالب</span>
              </div>
              <button 
                onClick={handleLogout}
                className="flex items-center px-3 py-2 text-sm text-gray-700 hover:text-gray-900 border border-gray-300 rounded-md hover:bg-gray-50"
              >
                <LogOut className="h-4 w-4 ml-2" />
                تسجيل خروج
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <div className="mb-8">
          <nav className="flex space-x-8 space-x-reverse">
            {[
              { id: 'home', label: 'الرئيسية', icon: Home },
              { id: 'chat', label: 'المساعد الذكي', icon: MessageCircle },
              { id: 'summarize', label: 'التلخيص الذكي', icon: FileText },
              { id: 'calendar', label: 'التقويم', icon: Calendar },
              { id: 'notifications', label: 'الإشعارات', icon: Bell }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                  activeTab === tab.id
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                <tab.icon className="h-4 w-4 ml-2" />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="bg-white rounded-lg shadow">
          {activeTab === 'home' && (
            <div className="p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">مرحباً بك في AcademicPlus</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <MessageCircle className="h-8 w-8 text-blue-600 mb-2" />
                  <h3 className="font-semibold text-gray-900">المساعد الذكي</h3>
                  <p className="text-sm text-gray-600">احصل على إجابات فورية لأسئلتك الأكاديمية</p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <FileText className="h-8 w-8 text-green-600 mb-2" />
                  <h3 className="font-semibold text-gray-900">التلخيص الذكي</h3>
                  <p className="text-sm text-gray-600">لخص النصوص الطويلة بذكاء اصطناعي</p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <Calendar className="h-8 w-8 text-purple-600 mb-2" />
                  <h3 className="font-semibold text-gray-900">التقويم الأكاديمي</h3>
                  <p className="text-sm text-gray-600">تابع مواعيدك ومهامك الدراسية</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'chat' && (
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-gray-900">المساعد الذكي</h2>
                <button
                  onClick={startNewConversation}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  محادثة جديدة
                </button>
              </div>
              
              <div className="border rounded-lg h-96 flex flex-col">
                <div className="flex-1 p-4 overflow-y-auto">
                  {chatHistory.length === 0 ? (
                    <div className="text-center text-gray-500 mt-8">
                      <MessageCircle className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>ابدأ محادثة جديدة مع المساعد الذكي</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {chatHistory.map((message, index) => (
                        <div
                          key={index}
                          className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                              message.role === 'user'
                                ? 'bg-blue-600 text-white'
                                : 'bg-gray-100 text-gray-900'
                            }`}
                          >
                            {message.content}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  {chatLoading && (
                    <div className="flex justify-start">
                      <div className="bg-gray-100 px-4 py-2 rounded-lg">
                        <Loader2 className="h-4 w-4 animate-spin" />
                      </div>
                    </div>
                  )}
                </div>
                
                <form onSubmit={handleChatSubmit} className="p-4 border-t">
                  <div className="flex space-x-2 space-x-reverse">
                    <input
                      type="text"
                      value={chatMessage}
                      onChange={(e) => setChatMessage(e.target.value)}
                      placeholder="اكتب سؤالك هنا..."
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      disabled={chatLoading}
                    />
                    <button
                      type="submit"
                      disabled={chatLoading || !chatMessage.trim()}
                      className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Send className="h-4 w-4" />
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {activeTab === 'summarize' && (
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">التلخيص الذكي</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    النص المراد تلخيصه
                  </label>
                  <textarea
                    value={summarizeText}
                    onChange={(e) => setSummarizeText(e.target.value)}
                    placeholder="الصق النص الذي تريد تلخيصه هنا..."
                    rows={6}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <button
                  onClick={handleSummarize}
                  disabled={summaryLoading || !summarizeText.trim()}
                  className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                >
                  {summaryLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin ml-2" />
                  ) : (
                    <FileText className="h-4 w-4 ml-2" />
                  )}
                  تلخيص النص
                </button>
                
                {summaryResult && (
                  <div className="mt-6 p-4 border rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-2">الملخص:</h3>
                    {summaryResult.success ? (
                      <p className="text-gray-700">{summaryResult.summary}</p>
                    ) : (
                      <p className="text-red-600">{summaryResult.error}</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'calendar' && (
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">التقويم الأكاديمي</h2>
              <div className="text-center text-gray-500 mt-8">
                <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>سيتم إضافة التقويم الأكاديمي قريباً</p>
              </div>
            </div>
          )}

          {activeTab === 'notifications' && (
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">الإشعارات</h2>
              <div className="text-center text-gray-500 mt-8">
                <Bell className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>لا توجد إشعارات جديدة</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;

